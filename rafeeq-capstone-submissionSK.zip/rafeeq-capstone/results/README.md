# Evaluation results

Run date: 2026-10-27. Model: `gpt-5-nano` through the Manus OpenAI-compatible proxy, with cache enabled. Suite: 15 tasks, one trial per task.

| Config | Pass rate | Pass^k | Average steps |
|---|---:|---:|---:|
| A | 0.87 (13/15) | 0.87 | see `summary.json` |
| B | 0.93 (14/15) | 0.93 | see `summary.json` |

A is the baseline `AGENTS.md` specification. B adds one instruction to retrieve policy before fee, deadline, or working-hours answers. The remaining recurring miss is `reschedule`: the model sometimes explains the requested change without calling the write tool. This is a harness/prompt improvement target, not evidence that the write tool itself bypassed approval.

Files:

- `eval-A.csv`: per-task results for A.
- `eval-B.csv`: per-task results for B.
- `error-analysis.csv`: grouped per-task pass indicators from the evaluator.
- `summary.json`: machine-readable summary.
